<?php
session_start();
include 'config/db.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Use prepared statement for security
$stmt = $conn->prepare("SELECT * FROM tasks WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Task Tracker - Dashboard</title>
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f9fafe 100%);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 950px;
            margin: 48px auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(74,144,226,0.10);
            padding: 40px 48px 48px 48px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }
        h1 {
            color: #2563eb;
            font-size: 2.2rem;
            letter-spacing: 2px;
            margin: 0;
        }
        .logout-btn {
            background: #e74c3c;
            color: #fff;
            border: none;
            padding: 10px 26px;
            border-radius: 7px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            box-shadow: 0 2px 8px rgba(231,76,60,0.08);
            transition: background 0.2s;
        }
        .logout-btn:hover {
            background: #c0392b;
        }
        h2 {
            color: #2563eb;
            margin-bottom: 18px;
            font-size: 1.4rem;
            letter-spacing: 1px;
        }
        .add-btn {
            display: inline-block;
            background: #2563eb;
            color: #fff;
            padding: 10px 22px;
            border-radius: 6px;
            font-weight: 600;
            text-decoration: none;
            margin-bottom: 18px;
            box-shadow: 0 2px 8px rgba(74,144,226,0.08);
            transition: background 0.2s;
        }
        .add-btn:hover {
            background: #174ea6;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
            background: #f8fbff;
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 14px 12px;
            text-align: left;
        }
        th {
            background: #e3f0ff;
            color: #2563eb;
            font-weight: 700;
            font-size: 1rem;
        }
        tr:nth-child(even) {
            background: #f4f6fb;
        }
        tr:hover {
            background: #e3eefd;
            transition: background 0.2s;
        }
        .actions a {
            margin-right: 10px;
            color: #e67e22;
            font-weight: 500;
            text-decoration: none;
            transition: color 0.2s;
        }
        .actions a:last-child {
            color: #e74c3c;
        }
        .actions a:hover {
            text-decoration: underline;
            color: #174ea6;
        }
        @media (max-width: 700px) {
            .container { padding: 18px 6px; }
            table, th, td { font-size: 0.95rem; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="top-bar">
        <h1>Task Tracker</h1>
        <form action="logout.php" method="post" style="margin:0;">
            <button class="logout-btn" type="submit">Logout</button>
        </form>
    </div>
    <h2>My Tasks</h2>
    <a class="add-btn" href="add_task.php">+ Add Task</a>
    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= htmlspecialchars($row['description']) ?></td>
                <td><?= htmlspecialchars($row['due_date']) ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td class="actions">
                    <a href="edit_task.php?id=<?= $row['id'] ?>">Edit</a>
                    <a href="delete_task.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this task?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
