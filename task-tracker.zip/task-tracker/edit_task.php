<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM tasks WHERE id = $id AND user_id = " . $_SESSION['user_id']);
$task = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $due_date = $_POST['due_date'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE tasks SET title=?, description=?, due_date=?, status=? WHERE id=? AND user_id=?");
    $stmt->bind_param("ssssii", $title, $description, $due_date, $status, $id, $_SESSION['user_id']);
    $stmt->execute();
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Task Tracker - <?= isset($task) ? 'Edit' : 'Add' ?> Task</title>
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f9fafe 100%);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .task-container {
            max-width: 430px;
            margin: 90px auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(74,144,226,0.10);
            padding: 44px 36px 36px 36px;
        }
        h2 {
            color: #2563eb;
            text-align: center;
            margin-bottom: 32px;
            letter-spacing: 1px;
            font-size: 2rem;
        }
        input[type="text"], input[type="date"], textarea, select {
            width: 100%;
            padding: 13px 12px;
            margin-bottom: 20px;
            border: 1.5px solid #e3f0ff;
            border-radius: 7px;
            font-size: 1rem;
            background: #f8fbff;
            transition: border 0.2s;
            resize: none;
        }
        input:focus, textarea:focus, select:focus {
            border: 1.5px solid #2563eb;
            outline: none;
        }
        button[type="submit"] {
            width: 100%;
            background: #2563eb;
            color: #fff;
            border: none;
            padding: 13px 0;
            border-radius: 7px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
            margin-bottom: 6px;
        }
        button[type="submit"]:hover {
            background: #174ea6;
        }
        .back-link {
            display: block;
            text-align: center;
            margin-top: 18px;
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="task-container">
    <h2><?= isset($task) ? 'Edit Task' : 'Add Task' ?></h2>
    <form method="POST">
        <input type="text" name="title" value="<?= $task['title'] ?>" required><br>
        <textarea name="description"><?= $task['description'] ?></textarea><br>
        <input type="date" name="due_date" value="<?= $task['due_date'] ?>" required><br>
        <select name="status">
            <option <?= $task['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
            <option <?= $task['status'] == 'Completed' ? 'selected' : '' ?>>Completed</option>
        </select><br>
        <button type="submit">Update</button>
    </form>
    <a class="back-link" href="dashboard.php">&larr; Back to Dashboard</a>
</div>
</body>
</html>
