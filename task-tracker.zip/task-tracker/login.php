<?php
session_start();
ob_start(); // ← This prevents "header already sent" error
include __DIR__ . '/config/db.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            
            // ✅ Redirect: no output must come before this line!
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "❌ Invalid password.";
        }
    } else {
        $error = "❌ No user found.";
    }
}
ob_end_flush(); // Stop output buffering here
?>

<!DOCTYPE html>
<html>
<head>
    <title>Task Tracker - Login</title>
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f9fafe 100%);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .login-container {
            max-width: 400px;
            margin: 90px auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 8px 32px rgba(74,144,226,0.10);
            padding: 44px 36px 36px 36px;
        }
        h2 {
            color: #2563eb;
            text-align: center;
            margin-bottom: 32px;
            letter-spacing: 1px;
            font-size: 2rem;
        }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 13px 12px;
            margin-bottom: 20px;
            border: 1.5px solid #e3f0ff;
            border-radius: 7px;
            font-size: 1rem;
            background: #f8fbff;
            transition: border 0.2s;
        }
        input[type="email"]:focus, input[type="password"]:focus {
            border: 1.5px solid #2563eb;
            outline: none;
        }
        button[type="submit"] {
            width: 100%;
            background: #2563eb;
            color: #fff;
            border: none;
            padding: 13px 0;
            border-radius: 7px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s;
            margin-bottom: 6px;
        }
        button[type="submit"]:hover {
            background: #174ea6;
        }
        .register-link {
            display: block;
            text-align: center;
            margin-top: 18px;
            color: #2563eb;
            text-decoration: none;
            font-weight: 500;
        }
        .register-link:hover {
            text-decoration: underline;
        }
        .error-message {
            color: #e74c3c;
            background: #fdecea;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 7px;
            margin-bottom: 18px;
            text-align: center;
        }
    </style>
</head>
<body>
<div class="login-container">
    <h2>Task Tracker Login</h2>
    <?php if (!empty($error)): ?>
        <div class="error-message"><?= $error ?></div>
    <?php endif; ?>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>
    <a class="register-link" href="register.php">Don't have an account? Register here</a>
</div>
</body>
</html>
