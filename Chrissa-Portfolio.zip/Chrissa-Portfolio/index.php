<?php
// index.php - Portfolio Website
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Portfolio - Chrissa May Canedo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"/>

  <style>
    /* 1. Balance & Unity: Consistent spacing, alignment, and color harmony */
    body {
      font-family: 'Montserrat', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(120deg, #fdf6f0 0%, #e3e6f3 100%);
      color: #232946;
      margin: 0;
      padding: 0;
    }

    nav.navbar {
      background: linear-gradient(90deg, #7f53ac 0%, #647dee 100%);
      box-shadow: 0 2px 12px rgba(100, 125, 222, 0.10);
    }
    nav.navbar a {
      color: #fff !important;
      font-weight: 600;
      letter-spacing: 1px;
      transition: color 0.2s;
    }
    nav.navbar a:hover {
      color: #ffd6e0 !important;
    }

    /* 2. Emphasis: Hero section with strong contrast */
    .hero {
      text-align: center;
      padding: 80px 20px 60px 20px;
      background: linear-gradient(135deg, #e3e6f3 0%, #fdf6f0 100%);
      border-bottom: 4px solid #7f53ac;
    }
    .hero img {
      border-radius: 50%;
      max-width: 170px;
      border: 5px solid #fff;
      box-shadow: 0 8px 32px rgba(100, 125, 222, 0.18);
      background: #fff;
      margin-bottom: 18px;
    }
    .hero h1 {
      color: #7f53ac;
      letter-spacing: 3px;
      font-size: 2.8rem;
      margin-top: 18px;
      font-weight: 800;
      text-shadow: 0 2px 8px #e3e6f3;
    }

    /* 3. Repetition: Section titles and cards */
    .section-title {
      font-weight: 700;
      text-align: center;
      margin: 56px 0 28px;
      color: #7f53ac;
      letter-spacing: 1.5px;
      font-size: 2.1rem;
      text-transform: uppercase;
      border-bottom: 2px solid #e3e6f3;
      display: inline-block;
      padding-bottom: 6px;
    }

    /* 4. Proportion & Movement: About section */
    .about {
      background: #fff;
      border-radius: 18px;
      padding: 48px 36px;
      box-shadow: 0 8px 32px rgba(100, 125, 222, 0.08);
      margin-bottom: 36px;
      max-width: 900px;
      margin-left: auto;
      margin-right: auto;
    }
    .about-text {
      font-size: 1.18rem;
      line-height: 1.8;
      color: #232946;
      text-align: justify;
    }

    /* 5. Contrast & Emphasis: Project and certificate cards */
    .project-card, .cert-card {
      background: #fff;
      border-radius: 18px;
      box-shadow: 0 6px 24px rgba(100, 125, 222, 0.10);
      transition: transform 0.3s, box-shadow 0.3s;
      text-align: center;
      padding: 26px;
      border: 2px solid #e3e6f3;
      min-height: 420px;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
    }
    .project-card:hover, .cert-card:hover {
      transform: translateY(-8px) scale(1.03);
      box-shadow: 0 16px 40px rgba(127, 83, 172, 0.18);
      border-color: #7f53ac;
    }
    .project-card img, .cert-card img {
      width: 100%;
      max-width: 340px;
      height: 180px;
      object-fit: cover;
      margin-bottom: 16px;
      border: 2px solid #c3b1e1;
      border-radius: 10px;
      background: #f8f8fa;
    }
    .project-card h5, .cert-card h6 {
      color: #7f53ac;
      font-weight: 700;
      margin-top: 12px;
      margin-bottom: 8px;
    }
    .project-card a.btn {
      margin-top: auto;
    }

    /* 6. Skills & Editor: Repetition and unity */
    .skills, .editor {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 32px;
      margin-bottom: 36px;
    }
    .skill-item, .editor-item {
      text-align: center;
      width: 120px;
      background: #f8f8fa;
      border-radius: 12px;
      padding: 18px 0;
      box-shadow: 0 2px 8px rgba(127, 83, 172, 0.06);
      transition: box-shadow 0.2s;
    }
    .skill-item img, .editor-item img {
      width: 65px;
      transition: transform 0.3s;
      filter: drop-shadow(0 4px 8px rgba(127, 83, 172, 0.10));
    }
    .skill-item img:hover, .editor-item img:hover {
      transform: scale(1.15);
    }
    .skill-item p, .editor-item p {
      margin-top: 10px;
      font-size: 1rem;
      font-weight: 600;
      color: #7f53ac;
      letter-spacing: 0.5px;
    }

    /* 7. Contact: Clean, inviting, and balanced */
    .contact {
      background: linear-gradient(135deg, #e3e6f3 0%, #fdf6f0 100%);
      padding: 70px 20px;
    }
    .contact form {
      background: #fff;
      border-radius: 18px;
      padding: 36px;
      box-shadow: 0 6px 24px rgba(127, 83, 172, 0.12);
      border: 2px solid #c3b1e1;
      max-width: 600px;
      margin: 0 auto;
    }
    .contact .form-label {
      color: #7f53ac;
      font-weight: 600;
    }
    .btn-primary {
      background: linear-gradient(90deg, #7f53ac 0%, #647dee 100%);
      border: none;
      color: #fff;
      font-weight: 700;
      letter-spacing: 1px;
      box-shadow: 0 2px 8px rgba(127, 83, 172, 0.10);
      transition: background 0.2s, color 0.2s;
    }
    .btn-primary:hover {
      background: linear-gradient(90deg, #647dee 0%, #7f53ac 100%);
      color: #ffd6e0;
    }

    /* Alerts */
    .alert-success {
      background: #e3ffe6;
      color: #232946;
      border: 1px solid #c3b1e1;
    }
    .alert-danger {
      background: #ffe6e6;
      color: #232946;
      border: 1px solid #e57373;
    }

    /* Footer: Unity and repetition */
    footer {
      background: linear-gradient(90deg, #7f53ac 0%, #647dee 100%);
      color: #fff;
      text-align: center;
      padding: 24px;
      margin-top: 60px;
      letter-spacing: 1px;
      font-size: 1.08rem;
      box-shadow: 0 -2px 12px rgba(127, 83, 172, 0.08);
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg sticky-top">
  <div class="container">
    <a class="navbar-brand text-white fw-bold" href="#">By Chrissa May Canedo</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navmenu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navmenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#about">About Me</a></li>
        <li class="nav-item"><a class="nav-link" href="#projects">Projects</a></li>
        <li class="nav-item"><a class="nav-link" href="#skills">Skills</a></li>
        <li class="nav-item"><a class="nav-link" href="#certificates">Certificates</a></li>
        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
      </ul>
    </div>
  </div>
</nav>

<!-- Hero Section -->
<section class="hero">
  <img src="profile.png" alt="Profile Picture">
  <h1 class="mt-4 fw-bold">PORTFOLIO</h1>
</section>

<!-- About Me -->
<section id="about" class="about container mt-5">
  <h2 class="section-title">ABOUT ME</h2>
  <p class="about-text">
    I’m <strong>Chrissa May Canedo</strong>, an aspiring IT professional with a passion for building smart, user-focused systems. 
    I thrive in environments that allow me to combine technical know-how with creative thinking. 
    My portfolio includes appointment systems, calculators, and dashboard apps, 
    and I’m excited to keep learning and growing as a developer and designer.
  </p>
</section>

<!-- Featured Projects -->
<section id="projects" class="container mt-5">
  <h2 class="section-title">Featured Projects</h2>
  <div id="projectCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <div class="project-card">
          <img src="Projects/Appointment.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold">Appointment System</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Appointment%20App.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
      <div class="carousel-item">
        <div class="project-card">
          <img src="Projects/bmi-calculator.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold">BMI Calculator</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/bmi%20calcultor.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
      <div class="carousel-item">
        <div class="project-card">
          <img src="Projects/onlinelibrary.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold">Online Library Management System</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Online%20BookStore.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
      <div class="carousel-item">
        <div class="project-card">
          <img src="Projects/personal.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold">Personal Notes App</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Create%20Notes%20App.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
      <div class="carousel-item">     
        <div class="project-card">
          <img src="Projects/studentdashboard.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold">Student Dashboard with Theme Reference</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Student%20Dashboard%20with%20Theme%20Preference.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
        <div class="carousel-item">     
        <div class="project-card">
          <img src="Projects/submitrack.jpg" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold"> Assignment Submission Track Portal</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Student-AssignmentSubmission.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
              <div class="carousel-item">     
        <div class="project-card">
          <img src="Projects/tasktracker.png" class="img-fluid" alt="Project">
          <h5 class="mt-3 fw-bold"> Task Tracker Management System</h5>
          <a href="https://github.com/BSIT-3B/Chrissa-Canedo/blob/main/Student-AssignmentSubmission.zip" class="btn btn-primary mt-2">View on GitHub</a>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#projectCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#projectCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
</section>

<!-- Skills -->
<section id="skills" class="container mt-5">
  <h2 class="section-title">SKILLS</h2>
  <div class="skills">
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" alt="HTML">
      <p>HTML</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" alt="CSS3">
      <p>CSS3</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" alt="JavaScript">
      <p>JavaScript</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/php/php-original.svg" alt="PHP">
      <p>PHP</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg" alt="ReactJS">
      <p>ReactJS</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" alt="Java">
      <p>Java</p>
    </div>
    <div class="skill-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" alt="Python">
      <p>Python</p>
    </div>
  </div>

  <h3 class="section-title">EDITOR TOOLS</h3>
  <div class="editor">
    <div class="editor-item">
      <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/figma/figma-original.svg" alt="Figma">
      <p>Figma</p>
    </div>
    <div class="editor-item">
      <img src="https://logohistory.net/wp-content/uploads/2023/07/Canva-Emblem.png" alt="Canva">
      <p>Canva</p>
    </div>
    <div class="editor-item">
      <img src="https://freelogopng.com/images/all_img/1664284918capcut-icon-png.png" alt="CapCut">
      <p>CapCut</p>
    </div>
  </div>
</section>

<!-- Certificates -->
<section id="certificates" class="container mt-5">
  <h2 class="section-title">Certificates</h2>
  <div id="certCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <div class="cert-card">
          <img src="Certificates/1.jpeg" alt="Java Programming">
          <h6 class="mt-3 fw-bold">Java Programming</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/2.jpg" alt="Networking">
          <h6 class="mt-3 fw-bold">Computer Networks</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/3.png" alt="Cyber Security">
          <h6 class="mt-3 fw-bold">Cybersecurity Basics</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/4.png" alt="Certificate 4" class="img-fluid">
          <h6 class="mt-3 fw-bold">Setting Up Computer Networks</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/5.png" alt="Certificate 5" class="img-fluid">
          <h6 class="mt-3 fw-bold">Introduction to CSS</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/6.png" alt="Certificate 6" class="img-fluid">
          <h6 class="mt-3 fw-bold">Installing & Configuring Systems</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/7.png" alt="Certificate 7" class="img-fluid">
          <h6 class="mt-3 fw-bold">Microsoft Office Specialist</h6>
        </div>
      </div>
      <div class="carousel-item">
        <div class="cert-card">
          <img src="Certificates/8.png" alt="Certificate 8" class="img-fluid">
          <h6 class="mt-3 fw-bold">Introduction to CyberSecurity</h6>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#certCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#certCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon"></span>
    </button>
  </div>
</section>

<!-- Contact -->
<section id="contact" class="contact mt-5">
  <h2 class="section-title">Send Me a Message</h2>
  <div class="container">
    <form>
      <div class="mb-3">
        <label class="form-label">Your Name</label>
        <input type="text" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Your Email</label>
        <input type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Message</label>
        <textarea class="form-control" rows="4" required></textarea>
      </div>
      <button class="btn btn-primary">Submit</button>
    </form>
  </div>
</section>

<!-- Footer -->
<footer>
  <p>&copy; 2025 Chrissa May Canedo | All Rights Reserved</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
